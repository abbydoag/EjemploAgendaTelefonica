/**
 * 
 */


/**
 * @author MAAG
 *
 */
public class NumeroRepetidoException extends Exception {
	
	public NumeroRepetidoException(String message) {
		super(message);
	}
}
