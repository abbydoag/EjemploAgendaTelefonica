/**
 * 
 */

/**
 * @author MAAG
 *
 */
public interface IFigura3D {
	public double calcularVolumen();
}
