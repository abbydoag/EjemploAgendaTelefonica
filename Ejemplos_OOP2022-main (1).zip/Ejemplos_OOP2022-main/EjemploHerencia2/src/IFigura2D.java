/**
 * 
 */

/**
 * @author MAAG
 *
 */
public interface IFigura2D {

	public double calcularPerimetro();
}
