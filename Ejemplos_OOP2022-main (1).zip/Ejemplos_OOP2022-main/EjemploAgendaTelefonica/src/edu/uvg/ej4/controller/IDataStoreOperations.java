/**
 * 
 */
package edu.uvg.ej4.controller;

/**
 * @author MAAG
 *
 */
public interface IDataStoreOperations {

	public void saveData() throws Exception;
	public void getData() throws Exception;
	
}
